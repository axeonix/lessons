@echo OFF

set JAVA_HOME=.\jdk1.8.0_171\jre

set CLASSPATH=.\lib\business-objects.jar
set CLASSPATH=%CLASSPATH%;.\lib\common.jar
set CLASSPATH=%CLASSPATH%;.\lib\common-framework.jar
set CLASSPATH=%CLASSPATH%;.\lib\commons-logging-1.2-adapters.jar
set CLASSPATH=%CLASSPATH%;.\lib\commons-logging-1.2-api.jar
set CLASSPATH=%CLASSPATH%;.\lib\commons-logging-1.2.jar
set CLASSPATH=%CLASSPATH%;.\lib\crm.jar
set CLASSPATH=%CLASSPATH%;.\lib\forms.jar
set CLASSPATH=%CLASSPATH%;.\lib\formsrt.jar
set CLASSPATH=%CLASSPATH%;.\lib\gui.jar
set CLASSPATH=%CLASSPATH%;.\lib\help.jar
set CLASSPATH=%CLASSPATH%;.\lib\i18n-common.jar
set CLASSPATH=%CLASSPATH%;.\lib\i18n-gui.jar
set CLASSPATH=%CLASSPATH%;.\lib\images.jar
set CLASSPATH=%CLASSPATH%;.\lib\itext-1.4.2.jar
set CLASSPATH=%CLASSPATH%;.\lib\jasperreports-1.2.5.jar
set CLASSPATH=%CLASSPATH%;.\lib\javassist-3.15.0.GA.jar
set CLASSPATH=%CLASSPATH%;.\lib\jcommon-1.0.15.jar
set CLASSPATH=%CLASSPATH%;.\lib\jfreechart-1.0.12.jar
set CLASSPATH=%CLASSPATH%;.\lib\jh.jar
set CLASSPATH=%CLASSPATH%;.\lib\jhelpaction.jar
set CLASSPATH=%CLASSPATH%;.\lib\jide-oss-3.1.1.jar
set CLASSPATH=%CLASSPATH%;.\lib\jnlp.jar
set CLASSPATH=%CLASSPATH%;.\lib\jsearch.jar
set CLASSPATH=%CLASSPATH%;.\lib\jtattoo-1.3.jar
set CLASSPATH=%CLASSPATH%;.\lib\log4j-1.2.15.jar
set CLASSPATH=%CLASSPATH%;.\lib\microba-0.4.4.4.jar
set CLASSPATH=%CLASSPATH%;.\lib\plugins-framework-common.jar
set CLASSPATH=%CLASSPATH%;.\lib\plugins-framework.jar
set CLASSPATH=%CLASSPATH%;.\lib\properties.jar
set CLASSPATH=%CLASSPATH%;.\lib\scannotation-1.0.3.jar
set CLASSPATH=%CLASSPATH%;.\lib\shopping-cart-plugin-common.jar
set CLASSPATH=%CLASSPATH%;.\lib\shopping-cart-plugin.jar
set CLASSPATH=%CLASSPATH%;.\lib\ui-framework.jar
set CLASSPATH=%CLASSPATH%;.\lib\ups-plugin-common.jar
set CLASSPATH=%CLASSPATH%;.\lib\ups-plugin.jar
set CLASSPATH=%CLASSPATH%;.\lib\webinfo-plugin-common.jar
set CLASSPATH=%CLASSPATH%;.\lib\webinfo-plugin.jar
set CLASSPATH=%CLASSPATH%;.

echo ON

rem %JAVA_HOME%\bin\java -Dcrm.debug=true -Dcom.axeonix.level=FINER -DSERVER_URL=https://www.bladesllc.com/ -Dcrm.jnlp.launch=true -Dservice.type=http -Dservice.url=https://www.bladesllc.com/ -classpath %CLASSPATH% com.axeonix.crm.gui.CRMLauncher

rem For debugging purposes:
rem %JAVA_HOME%\bin\java -agentlib:jdwp=transport=dt_socket,address=7700,server=y,suspend=n -Dcrm.debug=true -Dcom.axeonix.level=FINEST -DSERVER_URL=https://www.bladesllc.com/ -Dcrm.jnlp.launch=true -Dservice.type=http -Dservice.url=https://www.bladesllc.com/ -classpath %CLASSPATH% com.axeonix.crm.gui.CRMLauncher

%JAVA_HOME%\bin\java -DSERVER_URL=https://www.bladesllc.com/ -Dservice.content.encoding=gzip -Dcrm.jnlp.launch=true -Dservice.type=http -Dservice.url=https://www.bladesllc.com/ -classpath %CLASSPATH% com.axeonix.crm.gui.CRMLauncher



